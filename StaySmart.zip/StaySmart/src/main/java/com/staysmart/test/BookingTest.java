
package com.staysmart.test;

import java.time.LocalDate;
import java.util.List;

import com.staysmart.model.Booking;
import com.staysmart.model.User;
import com.staysmart.service.BookingService;
import com.staysmart.service.UserService;

public class BookingTest {

    public static void main(String[] args) {

        UserService userService = new UserService();
        BookingService bookingService = new BookingService();

        try {

            // STEP 1: User login
            User user = userService.login(
                    "demo@staysmart.com",
                    "User@123"
            );

            System.out.println("User login successful!");

            // STEP 2: User requests property ID 1
            boolean requested = bookingService.requestBooking(
                    user,
                    1,
                    LocalDate.now().plusDays(1)
            );

            if (requested) {
                System.out.println("Booking request submitted!");
            }

            // STEP 3: Display user's bookings
            System.out.println("\n--- MY BOOKINGS ---");

            List<Booking> myBookings =
                    bookingService.getMyBookings(user);

            for (Booking booking : myBookings) {
                System.out.println(
                        "Booking ID: " + booking.getId()
                        + " | Property: " + booking.getHouseName()
                        + " | Status: " + booking.getStatus()
                );
            }

            // STEP 4: House Owner login
            User owner = userService.login(
                    "owner.demo@staysmart.com",
                    "Owner@123"
            );

            System.out.println("\nOwner login successful!");

            // STEP 5: Display pending requests
            System.out.println("\n--- PENDING BOOKINGS ---");

            List<Booking> pending =
                    bookingService.getOwnerPendingBookings(owner);

            for (Booking booking : pending) {
                System.out.println(
                        "Booking ID: " + booking.getId()
                        + " | User: " + booking.getUserName()
                        + " | Property: " + booking.getHouseName()
                        + " | Date: " + booking.getBookingDate()
                );
            }

            // STEP 6: Approve the first pending request
            if (!pending.isEmpty()) {

                int bookingId = pending.get(0).getId();

                boolean approved = bookingService.approveBooking(
                        owner, bookingId
                );

                if (approved) {
                    System.out.println(
                            "\nBooking approved successfully!"
                    );
                }
            }

            // STEP 7: Display updated booking status
            System.out.println("\n--- UPDATED BOOKING STATUS ---");

            myBookings = bookingService.getMyBookings(user);

            for (Booking booking : myBookings) {
                System.out.println(
                        "Booking ID: " + booking.getId()
                        + " | Property: " + booking.getHouseName()
                        + " | Status: " + booking.getStatus()
                );
            }

        } catch (Exception e) {

            System.out.println("Booking module test failed!");
            e.printStackTrace();
        }
    }
}



package com.staysmart.model;

import java.math.BigDecimal;

public class House {

    private int id;
    private int ownerId;
    private String name;
    private String type;
    private String city;
    private String address;
    private String facilities;
    private BigDecimal monthlyRent;
    private BigDecimal monthlyUtilities;
    private BigDecimal monthlyMaintenance;
    private BigDecimal monthlyInternet;
    private boolean available;

    public House() {
    }

    public House(int id, int ownerId, String name, String type,
            String city, String address, String facilities,
            BigDecimal monthlyRent, BigDecimal monthlyUtilities,
            BigDecimal monthlyMaintenance, BigDecimal monthlyInternet,
            boolean available) {

        this.id = id;
        this.ownerId = ownerId;
        this.name = name;
        this.type = type;
        this.city = city;
        this.address = address;
        this.facilities = facilities;
        this.monthlyRent = monthlyRent;
        this.monthlyUtilities = monthlyUtilities;
        this.monthlyMaintenance = monthlyMaintenance;
        this.monthlyInternet = monthlyInternet;
        this.available = available;
    }

    public BigDecimal getTotalMonthlyCost() {
        return monthlyRent
                .add(monthlyUtilities)
                .add(monthlyMaintenance)
                .add(monthlyInternet);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getOwnerId() { return ownerId; }
    public void setOwnerId(int ownerId) { this.ownerId = ownerId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getFacilities() { return facilities; }
    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public BigDecimal getMonthlyRent() { return monthlyRent; }
    public void setMonthlyRent(BigDecimal monthlyRent) {
        this.monthlyRent = monthlyRent;
    }

    public BigDecimal getMonthlyUtilities() { return monthlyUtilities; }
    public void setMonthlyUtilities(BigDecimal monthlyUtilities) {
        this.monthlyUtilities = monthlyUtilities;
    }

    public BigDecimal getMonthlyMaintenance() {
        return monthlyMaintenance;
    }
    public void setMonthlyMaintenance(BigDecimal monthlyMaintenance) {
        this.monthlyMaintenance = monthlyMaintenance;
    }

    public BigDecimal getMonthlyInternet() { return monthlyInternet; }
    public void setMonthlyInternet(BigDecimal monthlyInternet) {
        this.monthlyInternet = monthlyInternet;
    }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) {
        this.available = available;
    }
}

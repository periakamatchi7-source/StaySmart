
package com.staysmart;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.staysmart.model.Booking;
import com.staysmart.model.House;
import com.staysmart.model.Role;
import com.staysmart.model.User;
import com.staysmart.service.BookingService;
import com.staysmart.service.HouseService;
import com.staysmart.service.UserService;

public class Main {

    private static final Scanner sc = new Scanner(System.in);

    private static final UserService userService = new UserService();
    private static final HouseService houseService = new HouseService();
    private static final BookingService bookingService =
            new BookingService();

    public static void main(String[] args) {

        try {
            userService.createDefaultAdmin();

            System.out.println("====================================");
            System.out.println("       WELCOME TO STAYSMART");
            System.out.println("====================================");

            while (true) {

                System.out.println("\n1. Register User");
                System.out.println("2. Register House Owner");
                System.out.println("3. Login");
                System.out.println("4. Exit");

                int choice = readInt("Enter your choice: ");

                switch (choice) {

                    case 1 -> registerUser();
                    case 2 -> registerOwner();
                    case 3 -> login();
                    case 4 -> {
                        System.out.println("Thank you for using StaySmart!");
                        return;
                    }
                    default -> System.out.println("Invalid choice.");
                }
            }

        } catch (Exception e) {
            System.out.println("Application error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // USER REGISTRATION
    private static void registerUser() {

        try {
            System.out.println("\n--- USER REGISTRATION ---");

            String name = readText("Enter full name: ");
            String email = readText("Enter email: ");
            String password = readText("Enter password: ");

            userService.registerUser(name, email, password);

            System.out.println("User registered successfully!");

        } catch (Exception e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    // HOUSE OWNER REGISTRATION
    private static void registerOwner() {

        try {
            System.out.println("\n--- HOUSE OWNER REGISTRATION ---");

            String name = readText("Enter full name: ");
            String email = readText("Enter email: ");
            String password = readText("Enter password: ");

            userService.registerOwner(name, email, password);

            System.out.println("Owner registration successful!");
            System.out.println("Please wait for Admin approval.");

        } catch (Exception e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    // LOGIN
    private static void login() {

        try {
            System.out.println("\n--- LOGIN ---");

            String email = readText("Enter email: ");
            String password = readText("Enter password: ");

            User user = userService.login(email, password);

            System.out.println("\nLogin successful!");
            System.out.println("Welcome, " + user.getFullName());

            if (user.getRole() == Role.ADMIN) {
                adminMenu(user);
            } else if (user.getRole() == Role.HOUSE_OWNER) {
                ownerMenu(user);
            } else {
                userMenu(user);
            }

        } catch (Exception e) {
            System.out.println("Login failed: " + e.getMessage());
        }
    }

    // USER MENU
    private static void userMenu(User user) {

        while (true) {

            System.out.println("\n========== USER MENU ==========");
            System.out.println("1. View Available Properties");
            System.out.println("2. Search by City");
            System.out.println("3. Search by Budget");
            System.out.println("4. Book Property");
            System.out.println("5. View My Bookings");
            System.out.println("6. Cancel Booking");
            System.out.println("7. Logout");

            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {

                    case 1 -> displayHouses(
                            houseService.getAvailableHouses());

                    case 2 -> {
                        String city = readText("Enter city: ");
                        displayHouses(
                                houseService.searchByCity(city));
                    }

                    case 3 -> {
                        BigDecimal budget =
                                readMoney("Enter total monthly budget: ");

                        displayHouses(
                                houseService.searchByBudget(budget));
                    }

                    case 4 -> bookProperty(user);

                    case 5 -> displayBookings(
                            bookingService.getMyBookings(user));

                    case 6 -> cancelBooking(user);

                    case 7 -> {
                        System.out.println("Logged out successfully.");
                        return;
                    }

                    default -> System.out.println("Invalid choice.");
                }

            } catch (Exception e) {
                System.out.println("Operation failed: " + e.getMessage());
            }
        }
    }

    // HOUSE OWNER MENU
    private static void ownerMenu(User owner) {

        while (true) {

            System.out.println("\n======= HOUSE OWNER MENU =======");
            System.out.println("1. Add Property");
            System.out.println("2. View My Properties");
            System.out.println("3. Update Property");
            System.out.println("4. Delete Property");
            System.out.println("5. View Booking Requests");
            System.out.println("6. Approve Booking");
            System.out.println("7. Reject Booking");
            System.out.println("8. Logout");

            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {

                    case 1 -> addProperty(owner);

                    case 2 -> displayHouses(
                            houseService.getMyHouses(owner));

                    case 3 -> updateProperty(owner);

                    case 4 -> deleteProperty(owner);

                    case 5 -> displayBookings(
                            bookingService.getOwnerPendingBookings(owner));

                    case 6 -> {
                        int id = readInt("Enter booking ID: ");

                        if (bookingService.approveBooking(owner, id)) {
                            System.out.println("Booking approved!");
                        }
                    }

                    case 7 -> {
                        int id = readInt("Enter booking ID: ");

                        if (bookingService.rejectBooking(owner, id)) {
                            System.out.println("Booking rejected!");
                        }
                    }

                    case 8 -> {
                        System.out.println("Logged out successfully.");
                        return;
                    }

                    default -> System.out.println("Invalid choice.");
                }

            } catch (Exception e) {
                System.out.println("Operation failed: " + e.getMessage());
            }
        }
    }

    // ADMIN MENU
    private static void adminMenu(User admin) {

        while (true) {

            System.out.println("\n========== ADMIN MENU ==========");
            System.out.println("1. View Pending Owner Requests");
            System.out.println("2. Approve House Owner");
            System.out.println("3. View Available Properties");
            System.out.println("4. Logout");

            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {

                    case 1 -> {
                        List<User> owners =
                                userService.getPendingOwners();

                        System.out.println("\n--- PENDING OWNERS ---");

                        if (owners.isEmpty()) {
                            System.out.println("No pending requests.");
                        }

                        for (User owner : owners) {
                            System.out.println(
                                    "ID: " + owner.getId()
                                    + " | Name: " + owner.getFullName()
                                    + " | Email: " + owner.getEmail()
                            );
                        }
                    }

                    case 2 -> {
                        int ownerId =
                                readInt("Enter owner ID to approve: ");

                        if (userService.approveOwner(admin, ownerId)) {
                            System.out.println("Owner approved!");
                        } else {
                            System.out.println("Owner not found or already approved.");
                        }
                    }

                    case 3 -> displayHouses(
                            houseService.getAvailableHouses());

                    case 4 -> {
                        System.out.println("Admin logged out.");
                        return;
                    }

                    default -> System.out.println("Invalid choice.");
                }

            } catch (Exception e) {
                System.out.println("Admin operation failed: "
                        + e.getMessage());
            }
        }
    }

    // ADD PROPERTY
    private static void addProperty(User owner) throws SQLException {

        System.out.println("\n--- ADD PROPERTY ---");

        String name = readText("Property name: ");
        String type = readText("Property type (PG/Hostel/Room): ");
        String city = readText("City: ");
        String address = readText("Address: ");
        String facilities = readText("Facilities: ");

        BigDecimal rent = readMoney("Monthly rent: ");
        BigDecimal utilities = readMoney("Monthly utilities: ");
        BigDecimal maintenance = readMoney("Monthly maintenance: ");
        BigDecimal internet = readMoney("Monthly internet: ");

        House house = new House(
                0,
                owner.getId(),
                name,
                type,
                city,
                address,
                facilities,
                rent,
                utilities,
                maintenance,
                internet,
                true
        );

        if (houseService.addHouse(owner, house)) {
            System.out.println("Property added successfully!");
            System.out.println("Total monthly cost: Rs. "
                    + house.getTotalMonthlyCost());
        }
    }

    // UPDATE PROPERTY
    private static void updateProperty(User owner) throws SQLException {

        displayHouses(houseService.getMyHouses(owner));

        int id = readInt("Enter property ID to update: ");

        House oldHouse = houseService.getHouseById(id);

        if (oldHouse == null || oldHouse.getOwnerId() != owner.getId()) {
            System.out.println("Property not found in your account.");
            return;
        }

        System.out.println("Enter updated property details:");

        String name = readText("Property name: ");
        String type = readText("Property type: ");
        String city = readText("City: ");
        String address = readText("Address: ");
        String facilities = readText("Facilities: ");

        BigDecimal rent = readMoney("Monthly rent: ");
        BigDecimal utilities = readMoney("Monthly utilities: ");
        BigDecimal maintenance = readMoney("Monthly maintenance: ");
        BigDecimal internet = readMoney("Monthly internet: ");

        House updated = new House(
                id,
                owner.getId(),
                name,
                type,
                city,
                address,
                facilities,
                rent,
                utilities,
                maintenance,
                internet,
                oldHouse.isAvailable()
        );

        if (houseService.updateHouse(owner, updated)) {
            System.out.println("Property updated successfully!");
        } else {
            System.out.println("Property update failed.");
        }
    }

    // DELETE PROPERTY
    private static void deleteProperty(User owner) throws SQLException {

        displayHouses(houseService.getMyHouses(owner));

        int id = readInt("Enter property ID to delete: ");

        String confirm = readText(
                "Are you sure you want to delete? (yes/no): ");

        if (confirm.equalsIgnoreCase("yes")) {

            if (houseService.deleteHouse(owner, id)) {
                System.out.println("Property deleted successfully!");
            } else {
                System.out.println("Property not found.");
            }

        } else {
            System.out.println("Delete cancelled.");
        }
    }

    // BOOK PROPERTY
    private static void bookProperty(User user) throws SQLException {

        displayHouses(houseService.getAvailableHouses());

        int houseId = readInt("Enter property ID to book: ");

        String dateInput = readText(
                "Enter booking date (YYYY-MM-DD): ");

        LocalDate bookingDate = LocalDate.parse(dateInput);

        if (bookingService.requestBooking(
                user, houseId, bookingDate)) {

            System.out.println("Booking request submitted!");
        }
    }

    // CANCEL BOOKING
    private static void cancelBooking(User user) throws SQLException {

        displayBookings(bookingService.getMyBookings(user));

        int id = readInt("Enter booking ID to cancel: ");

        if (bookingService.cancelBooking(user, id)) {
            System.out.println("Booking cancelled successfully!");
        }
    }

    // DISPLAY PROPERTY DETAILS
    private static void displayHouses(List<House> houses) {

        System.out.println("\n========== PROPERTIES ==========");

        if (houses.isEmpty()) {
            System.out.println("No properties found.");
            return;
        }

        for (House h : houses) {

            System.out.println("--------------------------------");
            System.out.println("Property ID: " + h.getId());
            System.out.println("Name: " + h.getName());
            System.out.println("Type: " + h.getType());
            System.out.println("City: " + h.getCity());
            System.out.println("Address: " + h.getAddress());
            System.out.println("Facilities: " + h.getFacilities());
            System.out.println("Rent: Rs. " + h.getMonthlyRent());
            System.out.println("Utilities: Rs. " + h.getMonthlyUtilities());
            System.out.println("Maintenance: Rs. " + h.getMonthlyMaintenance());
            System.out.println("Internet: Rs. " + h.getMonthlyInternet());
            System.out.println("Total Monthly Cost: Rs. "
                    + h.getTotalMonthlyCost());
            System.out.println("Available: " + h.isAvailable());
        }
    }

    // DISPLAY BOOKING DETAILS
    private static void displayBookings(List<Booking> bookings) {

        System.out.println("\n========== BOOKINGS ==========");

        if (bookings.isEmpty()) {
            System.out.println("No bookings found.");
            return;
        }

        for (Booking b : bookings) {

            System.out.println("--------------------------------");
            System.out.println("Booking ID: " + b.getId());
            System.out.println("Property: " + b.getHouseName());
            System.out.println("User: " + b.getUserName());
            System.out.println("Booking Date: " + b.getBookingDate());
            System.out.println("Status: " + b.getStatus());
        }
    }

    // INPUT METHODS
    private static String readText(String message) {

        System.out.print(message);
        return sc.nextLine().trim();
    }

    private static int readInt(String message) {

        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static BigDecimal readMoney(String message) {

        while (true) {
            try {
                System.out.print(message);

                BigDecimal value =
                        new BigDecimal(sc.nextLine().trim());

                if (value.signum() < 0) {
                    System.out.println("Amount cannot be negative.");
                    continue;
                }

                return value;

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid amount.");
            }
        }
    }
}


package com.staysmart.test;

import java.math.BigDecimal;
import java.util.List;

import com.staysmart.model.House;
import com.staysmart.model.User;
import com.staysmart.service.HouseService;
import com.staysmart.service.UserService;

public class HouseTest {

    public static void main(String[] args) {

        UserService userService = new UserService();
        HouseService houseService = new HouseService();

        try {

            // Login as an approved House Owner.
            User owner = userService.login(
                    "owner.demo@staysmart.com",
                    "Owner@123"
            );

            System.out.println("Owner login successful!");

            // Create a new property.
            House house = new House(
                    0,
                    owner.getId(),
                    "Sunshine PG",
                    "PG",
                    "Chennai",
                    "Velachery",
                    "Wi-Fi, Food, Security, Parking",
                    new BigDecimal("6000.00"),
                    new BigDecimal("500.00"),
                    new BigDecimal("300.00"),
                    new BigDecimal("200.00"),
                    true
            );

            boolean saved = houseService.addHouse(owner, house);

            if (saved) {
                System.out.println("\nProperty added successfully!");
            }

            // View owner's properties.
            System.out.println("\n--- MY PROPERTIES ---");

            List<House> myHouses = houseService.getMyHouses(owner);

            for (House h : myHouses) {
                displayHouse(h);
            }

            // Search by city.
            System.out.println("\n--- SEARCH BY CITY ---");

            List<House> cityResults =
                    houseService.searchByCity("Chennai");

            for (House h : cityResults) {
                displayHouse(h);
            }

            // Search by monthly budget.
            System.out.println("\n--- SEARCH BY BUDGET ---");

            List<House> budgetResults =
                    houseService.searchByBudget(
                            new BigDecimal("7000.00")
                    );

            for (House h : budgetResults) {
                displayHouse(h);
            }

        } catch (Exception e) {

            System.out.println("House module test failed!");
            e.printStackTrace();
        }
    }

    private static void displayHouse(House house) {

        System.out.println("--------------------------------");
        System.out.println("Property ID: " + house.getId());
        System.out.println("Name: " + house.getName());
        System.out.println("Type: " + house.getType());
        System.out.println("City: " + house.getCity());
        System.out.println("Address: " + house.getAddress());
        System.out.println("Facilities: " + house.getFacilities());
        System.out.println("Rent: Rs. " + house.getMonthlyRent());
        System.out.println("Utilities: Rs. " + house.getMonthlyUtilities());
        System.out.println("Maintenance: Rs. " + house.getMonthlyMaintenance());
        System.out.println("Internet: Rs. " + house.getMonthlyInternet());
        System.out.println("Total Monthly Cost: Rs. "
                + house.getTotalMonthlyCost());
        System.out.println("Available: " + house.isAvailable());
    }
}

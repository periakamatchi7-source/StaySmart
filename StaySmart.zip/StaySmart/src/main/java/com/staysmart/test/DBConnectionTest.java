
package com.staysmart.test;

import java.sql.Connection;
import com.staysmart.db.DBConnection;

public class DBConnectionTest {

    public static void main(String[] args) {

        try (Connection connection = DBConnection.getConnection()) {

            System.out.println("Database Connection Successful!");
            System.out.println("Connected Database: "
                    + connection.getCatalog());

        } catch (Exception e) {

            System.out.println("Database Connection Failed!");
            e.printStackTrace();
        }
    }
}

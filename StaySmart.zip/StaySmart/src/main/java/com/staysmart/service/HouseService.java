
package com.staysmart.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import com.staysmart.dao.HouseDAO;
import com.staysmart.model.House;
import com.staysmart.model.Role;
import com.staysmart.model.User;

public class HouseService {

    private final HouseDAO houseDAO = new HouseDAO();

    private void checkOwner(User owner) {

        if (owner == null ||
                owner.getRole() != Role.HOUSE_OWNER ||
                !owner.isApproved()) {
            throw new SecurityException(
                    "Only approved House Owners can manage properties."
            );
        }
    }

    private void validateHouse(House house) {

        if (house.getName() == null || house.getName().isBlank()
                || house.getCity() == null || house.getCity().isBlank()
                || house.getAddress() == null || house.getAddress().isBlank()
                || house.getType() == null || house.getType().isBlank()) {
            throw new IllegalArgumentException(
                    "Name, type, city and address are required."
            );
        }

        if (house.getMonthlyRent() == null ||
                house.getMonthlyUtilities() == null ||
                house.getMonthlyMaintenance() == null ||
                house.getMonthlyInternet() == null) {
            throw new IllegalArgumentException(
                    "All monthly charges are required."
            );
        }

        if (house.getMonthlyRent().signum() < 0 ||
                house.getMonthlyUtilities().signum() < 0 ||
                house.getMonthlyMaintenance().signum() < 0 ||
                house.getMonthlyInternet().signum() < 0) {
            throw new IllegalArgumentException(
                    "Monthly charges cannot be negative."
            );
        }
    }

    public boolean addHouse(User owner, House house) throws SQLException {

        checkOwner(owner);
        validateHouse(house);

        house.setOwnerId(owner.getId());
        house.setAvailable(true);

        return houseDAO.save(house);
    }

    public List<House> getMyHouses(User owner) throws SQLException {

        checkOwner(owner);
        return houseDAO.findByOwner(owner.getId());
    }

    public List<House> getAvailableHouses() throws SQLException {
        return houseDAO.findAllAvailable();
    }

    public House getHouseById(int id) throws SQLException {
        return houseDAO.findById(id);
    }

    public boolean updateHouse(User owner, House house) throws SQLException {

        checkOwner(owner);
        validateHouse(house);

        house.setOwnerId(owner.getId());

        return houseDAO.update(house);
    }

    public boolean deleteHouse(User owner, int houseId) throws SQLException {

        checkOwner(owner);

        return houseDAO.delete(houseId, owner.getId());
    }

    public List<House> searchByCity(String city) throws SQLException {

        if (city == null || city.isBlank()) {
            throw new IllegalArgumentException("City is required.");
        }

        return houseDAO.searchByCity(city.trim());
    }

    public List<House> searchByBudget(BigDecimal budget)
            throws SQLException {

        if (budget == null || budget.signum() < 0) {
            throw new IllegalArgumentException("Enter a valid budget.");
        }

        return houseDAO.searchByBudget(budget);
    }
}

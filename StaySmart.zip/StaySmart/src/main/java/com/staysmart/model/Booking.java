
package com.staysmart.model;

import java.time.LocalDate;

public class Booking {

    private int id;
    private int userId;
    private int houseId;
    private LocalDate bookingDate;
    private String status;
    private String houseName;
    private String userName;

    public Booking() {
    }

    public Booking(int id, int userId, int houseId,
            LocalDate bookingDate, String status) {
        this.id = id;
        this.userId = userId;
        this.houseId = houseId;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getHouseId() { return houseId; }
    public void setHouseId(int houseId) { this.houseId = houseId; }

    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getHouseName() { return houseName; }
    public void setHouseName(String houseName) {
        this.houseName = houseName;
    }

    public String getUserName() { return userName; }
    public void setUserName(String userName) {
        this.userName = userName;
    }
}

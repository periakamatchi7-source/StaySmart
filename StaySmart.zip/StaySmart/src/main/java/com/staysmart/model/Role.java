
package com.staysmart.model;

public enum Role {
    USER,
    HOUSE_OWNER,
    ADMIN
}

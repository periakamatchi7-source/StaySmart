
package com.staysmart.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/staysmart_v2";

    private static final String USERNAME = "root";

    // Enter your own MySQL password here.
    private static final String PASSWORD = "Prekash@2006";

    public static Connection getConnection() throws SQLException {

        return DriverManager.getConnection(
                URL,
                USERNAME,
                PASSWORD
        );
    }
}


package com.staysmart.dao;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.staysmart.db.DBConnection;
import com.staysmart.model.House;

public class HouseDAO {

    // ADD PROPERTY
    public boolean save(House house) throws SQLException {

        String sql = """
                INSERT INTO houses
                (owner_id, name, type, city, address, facilities,
                 monthly_rent, monthly_utilities,
                 monthly_maintenance, monthly_internet, available)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, house.getOwnerId());
            ps.setString(2, house.getName());
            ps.setString(3, house.getType());
            ps.setString(4, house.getCity());
            ps.setString(5, house.getAddress());
            ps.setString(6, house.getFacilities());
            ps.setBigDecimal(7, house.getMonthlyRent());
            ps.setBigDecimal(8, house.getMonthlyUtilities());
            ps.setBigDecimal(9, house.getMonthlyMaintenance());
            ps.setBigDecimal(10, house.getMonthlyInternet());
            ps.setBoolean(11, house.isAvailable());

            return ps.executeUpdate() == 1;
        }
    }

    // FIND PROPERTY BY ID
    public House findById(int id) throws SQLException {

        String sql = "SELECT * FROM houses WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapHouse(rs);
                }
            }
        }

        return null;
    }

    // VIEW ALL AVAILABLE PROPERTIES
    public List<House> findAllAvailable() throws SQLException {

        String sql = "SELECT * FROM houses WHERE available = TRUE ORDER BY id";
        List<House> houses = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                houses.add(mapHouse(rs));
            }
        }

        return houses;
    }

    // VIEW PROPERTIES OF ONE OWNER
    public List<House> findByOwner(int ownerId) throws SQLException {

        String sql = "SELECT * FROM houses WHERE owner_id = ? ORDER BY id";
        List<House> houses = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ownerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    houses.add(mapHouse(rs));
                }
            }
        }

        return houses;
    }

    // UPDATE PROPERTY
    public boolean update(House house) throws SQLException {

        String sql = """
                UPDATE houses
                SET name = ?, type = ?, city = ?, address = ?,
                    facilities = ?, monthly_rent = ?,
                    monthly_utilities = ?, monthly_maintenance = ?,
                    monthly_internet = ?
                WHERE id = ? AND owner_id = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, house.getName());
            ps.setString(2, house.getType());
            ps.setString(3, house.getCity());
            ps.setString(4, house.getAddress());
            ps.setString(5, house.getFacilities());
            ps.setBigDecimal(6, house.getMonthlyRent());
            ps.setBigDecimal(7, house.getMonthlyUtilities());
            ps.setBigDecimal(8, house.getMonthlyMaintenance());
            ps.setBigDecimal(9, house.getMonthlyInternet());
            ps.setInt(10, house.getId());
            ps.setInt(11, house.getOwnerId());

            return ps.executeUpdate() == 1;
        }
    }

    // DELETE PROPERTY
    public boolean delete(int id, int ownerId) throws SQLException {

        String sql = """
                DELETE FROM houses
                WHERE id = ? AND owner_id = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.setInt(2, ownerId);

            return ps.executeUpdate() == 1;
        }
    }

    // SEARCH BY CITY
    public List<House> searchByCity(String city) throws SQLException {

        String sql = """
                SELECT * FROM houses
                WHERE LOWER(city) = LOWER(?) AND available = TRUE
                """;

        List<House> houses = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, city);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    houses.add(mapHouse(rs));
                }
            }
        }

        return houses;
    }

    // SEARCH BY TOTAL MONTHLY BUDGET
    public List<House> searchByBudget(BigDecimal budget)
            throws SQLException {

        String sql = """
                SELECT * FROM houses
                WHERE available = TRUE
                AND (monthly_rent + monthly_utilities
                    + monthly_maintenance + monthly_internet) <= ?
                ORDER BY monthly_rent
                """;

        List<House> houses = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setBigDecimal(1, budget);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    houses.add(mapHouse(rs));
                }
            }
        }

        return houses;
    }

    // CONVERT RESULT SET INTO HOUSE OBJECT
    private House mapHouse(ResultSet rs) throws SQLException {

        return new House(
                rs.getInt("id"),
                rs.getInt("owner_id"),
                rs.getString("name"),
                rs.getString("type"),
                rs.getString("city"),
                rs.getString("address"),
                rs.getString("facilities"),
                rs.getBigDecimal("monthly_rent"),
                rs.getBigDecimal("monthly_utilities"),
                rs.getBigDecimal("monthly_maintenance"),
                rs.getBigDecimal("monthly_internet"),
                rs.getBoolean("available")
        );
    }
}


package com.staysmart.test;

import java.util.List;

import com.staysmart.model.User;
import com.staysmart.service.UserService;

public class OwnerApprovalTest {

    public static void main(String[] args) {

        UserService service = new UserService();

        try {
            service.createDefaultAdmin();

            // Register a demonstration owner if not already registered.
            String email = "owner.demo@staysmart.com";

            User owner = null;

            try {
                owner = service.registerOwner(
                        "Demo House Owner",
                        email,
                        "Owner@123"
                );

                System.out.println("Owner registration successful!");

            } catch (IllegalArgumentException e) {

                System.out.println(e.getMessage());
                owner = service.login(email, "Owner@123");
            }

            // Check pending owner requests.
            List<User> pendingOwners = service.getPendingOwners();

            System.out.println("\n--- PENDING OWNER REQUESTS ---");

            for (User pending : pendingOwners) {
                System.out.println(
                        "ID: " + pending.getId()
                        + " | Name: " + pending.getFullName()
                        + " | Email: " + pending.getEmail()
                );
            }

            // Admin login.
            User admin = service.login(
                    "admin@staysmart.com",
                    "Admin@123"
            );

            // Approve the owner if still pending.
            if (!owner.isApproved()) {

                boolean approved =
                        service.approveOwner(admin, owner.getId());

                if (approved) {
                    System.out.println("\nOwner approved successfully!");
                }
            } else {
                System.out.println("\nOwner is already approved.");
            }

            // Test owner login after approval.
            User loggedInOwner = service.login(
                    email,
                    "Owner@123"
            );

            System.out.println("\nOwner login successful!");
            System.out.println("Name: " + loggedInOwner.getFullName());
            System.out.println("Role: " + loggedInOwner.getRole());
            System.out.println("Approved: " + loggedInOwner.isApproved());

        } catch (Exception e) {
            System.out.println("Owner approval test failed!");
            e.printStackTrace();
        }
    }
}

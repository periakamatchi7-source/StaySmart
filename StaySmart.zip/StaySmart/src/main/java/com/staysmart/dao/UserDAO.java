
package com.staysmart.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.staysmart.db.DBConnection;
import com.staysmart.model.Role;
import com.staysmart.model.User;

public class UserDAO {

    public boolean emailExists(String email) throws SQLException {

        String sql = "SELECT id FROM app_users WHERE email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
    
    

    public boolean save(User user) throws SQLException {

        String sql = """
                INSERT INTO app_users
                (full_name, email, password_hash, role, approved)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getFullName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPasswordHash());
            ps.setString(4, user.getRole().name());
            ps.setBoolean(5, user.isApproved());

            return ps.executeUpdate() == 1;
        }
    }

    public User findByEmail(String email) throws SQLException {

        String sql = """
                SELECT id, full_name, email, password_hash, role, approved
                FROM app_users
                WHERE email = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapUser(rs);
                }
            }
        }

        return null;
    }

    public User findById(int id) throws SQLException {

        String sql = """
                SELECT id, full_name, email, password_hash, role, approved
                FROM app_users
                WHERE id = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapUser(rs);
                }
            }
        }

        return null;
    }

    public boolean updateApproval(int id, boolean approved)
            throws SQLException {

        String sql = """
                UPDATE app_users
                SET approved = ?
                WHERE id = ? AND role = 'HOUSE_OWNER'
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setBoolean(1, approved);
            ps.setInt(2, id);

            return ps.executeUpdate() == 1;
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {

        return new User(
                rs.getInt("id"),
                rs.getString("full_name"),
                rs.getString("email"),
                rs.getString("password_hash"),
                Role.valueOf(rs.getString("role")),
                rs.getBoolean("approved")
        );
    }
    

public List<User> findPendingOwners() throws SQLException {

    List<User> owners = new ArrayList<>();

    String sql = """
            SELECT id, full_name, email, password_hash, role, approved
            FROM app_users
            WHERE role = 'HOUSE_OWNER' AND approved = FALSE
            """;

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            owners.add(mapUser(rs));
        }
    }

    return owners;
}

}

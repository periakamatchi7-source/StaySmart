
package com.staysmart.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.staysmart.dao.BookingDAO;
import com.staysmart.model.Booking;
import com.staysmart.model.Role;
import com.staysmart.model.User;

public class BookingService {

    private final BookingDAO bookingDAO = new BookingDAO();

    public boolean requestBooking(
            User user, int houseId, LocalDate bookingDate)
            throws SQLException {

        if (user == null || user.getRole() != Role.USER) {
            throw new SecurityException(
                    "Only registered Users can request bookings.");
        }

        if (bookingDate == null ||
                bookingDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException(
                    "Booking date cannot be in the past.");
        }

        Booking booking = new Booking(
                0,
                user.getId(),
                houseId,
                bookingDate,
                "PENDING"
        );

        return bookingDAO.createBooking(booking);
    }

    public List<Booking> getMyBookings(User user)
            throws SQLException {

        if (user == null || user.getRole() != Role.USER) {
            throw new SecurityException(
                    "Only Users can view their bookings.");
        }

        return bookingDAO.findByUser(user.getId());
    }

    public List<Booking> getOwnerPendingBookings(User owner)
            throws SQLException {

        checkOwner(owner);
        return bookingDAO.findPendingByOwner(owner.getId());
    }

    public boolean approveBooking(User owner, int bookingId)
            throws SQLException {

        checkOwner(owner);

        return bookingDAO.updateBookingStatus(
                bookingId, owner.getId(), "APPROVED");
    }

    public boolean rejectBooking(User owner, int bookingId)
            throws SQLException {

        checkOwner(owner);

        return bookingDAO.updateBookingStatus(
                bookingId, owner.getId(), "REJECTED");
    }

    public boolean cancelBooking(User user, int bookingId)
            throws SQLException {

        if (user == null || user.getRole() != Role.USER) {
            throw new SecurityException(
                    "Only Users can cancel their bookings.");
        }

        return bookingDAO.cancelBooking(bookingId, user.getId());
    }

    private void checkOwner(User owner) {

        if (owner == null
                || owner.getRole() != Role.HOUSE_OWNER
                || !owner.isApproved()) {

            throw new SecurityException(
                    "Only approved House Owners can manage bookings.");
        }
    }
}

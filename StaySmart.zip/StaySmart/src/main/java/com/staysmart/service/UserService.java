
package com.staysmart.service;

import java.sql.SQLException;

import java.util.List;

import com.staysmart.dao.UserDAO;
import com.staysmart.model.Role;
import com.staysmart.model.User;

public class UserService {

    private final UserDAO userDAO = new UserDAO();

    public User registerUser(String name, String email, String password)
            throws SQLException {
        return register(name, email, password, Role.USER);
    }

    public User registerOwner(String name, String email, String password)
            throws SQLException {
        return register(name, email, password, Role.HOUSE_OWNER);
    }

    private User register(String name, String email, String password, Role role)
            throws SQLException {

        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name is required.");
        }

        if (email == null ||
                !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            throw new IllegalArgumentException("Enter a valid email.");
        }

        if (password == null || password.length() < 6) {
            throw new IllegalArgumentException(
                    "Password must contain at least 6 characters.");
        }

        email = email.trim().toLowerCase();

        if (userDAO.emailExists(email)) {
            throw new IllegalArgumentException("Email already registered.");
        }

        String passwordHash = PasswordUtil.hashPassword(password);

        boolean approved = role == Role.USER;

        User user = new User(
                0, name.trim(), email, passwordHash, role, approved
        );

        if (userDAO.save(user)) {
            return userDAO.findByEmail(email);
        }

        throw new SQLException("User registration failed.");
    }

    public User login(String email, String password) throws SQLException {

        if (email == null || password == null) {
            throw new IllegalArgumentException(
                    "Email and password are required.");
        }

        User user = userDAO.findByEmail(email.trim().toLowerCase());

        if (user == null ||
                !PasswordUtil.verifyPassword(
                        password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password.");
        }

        if (user.getRole() == Role.HOUSE_OWNER && !user.isApproved()) {
            throw new IllegalArgumentException(
                    "Your owner account is waiting for Admin approval.");
        }

        return user;
    }

    public void createDefaultAdmin() throws SQLException {

        String email = "admin@staysmart.com";

        if (!userDAO.emailExists(email)) {

            User admin = new User(
                    0,
                    "StaySmart Admin",
                    email,
                    PasswordUtil.hashPassword("Admin@123"),
                    Role.ADMIN,
                    true
            );

            if (!userDAO.save(admin)) {
                throw new SQLException("Could not create Admin.");
            }
        }
    }

public List<User> getPendingOwners() throws SQLException {
    return userDAO.findPendingOwners();
}

public boolean approveOwner(User admin, int ownerId)
        throws SQLException {

    if (admin == null || admin.getRole() != Role.ADMIN) {
        throw new SecurityException("Only Admin can approve owners.");
    }

    return userDAO.updateApproval(ownerId, true);
}



}

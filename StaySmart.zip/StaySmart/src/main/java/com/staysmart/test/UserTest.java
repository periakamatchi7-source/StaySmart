
package com.staysmart.test;

import com.staysmart.model.User;
import com.staysmart.service.UserService;

public class UserTest {

    public static void main(String[] args) {

        UserService userService = new UserService();

        try {

            // Create Admin account if it does not exist.
            userService.createDefaultAdmin();

            System.out.println("Default Admin account is ready.");

            // Register a demonstration user.
            String email = "demo@staysmart.com";

            try {
                User registered = userService.registerUser(
                        "Demo User",
                        email,
                        "User@123"
                );

                System.out.println("User registered successfully!");
                System.out.println("User ID: " + registered.getId());

            } catch (IllegalArgumentException e) {
                // Allows this test to run again without duplicate registration.
                System.out.println(e.getMessage());
            }

            // Test User login.
            User loggedIn = userService.login(email, "User@123");

            System.out.println("Login successful!");
            System.out.println("Welcome: " + loggedIn.getFullName());
            System.out.println("Role: " + loggedIn.getRole());

            // Test Admin login.
            User admin = userService.login(
                    "admin@staysmart.com",
                    "Admin@123"
            );

            System.out.println("Admin login successful: " + admin.getEmail());

        } catch (Exception e) {

            System.out.println("User module test failed!");
            e.printStackTrace();
        }
    }
}

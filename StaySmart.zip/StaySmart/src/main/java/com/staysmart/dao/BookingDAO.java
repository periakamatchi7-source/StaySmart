
package com.staysmart.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.staysmart.db.DBConnection;
import com.staysmart.model.Booking;

public class BookingDAO {

    // USER CREATES A BOOKING REQUEST
    public boolean createBooking(Booking booking) throws SQLException {

        String checkSql =
                "SELECT available FROM houses WHERE id = ? FOR UPDATE";

        String insertSql = """
                INSERT INTO bookings
                (user_id, house_id, booking_date, status)
                VALUES (?, ?, ?, 'PENDING')
                """;

        try (Connection con = DBConnection.getConnection()) {

            con.setAutoCommit(false);

            try {
                boolean available;

                try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                    ps.setInt(1, booking.getHouseId());

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException("Property not found.");
                        }
                        available = rs.getBoolean("available");
                    }
                }

                if (!available) {
                    throw new SQLException("Property is not available.");
                }

                try (PreparedStatement ps =
                        con.prepareStatement(insertSql)) {

                    ps.setInt(1, booking.getUserId());
                    ps.setInt(2, booking.getHouseId());
                    ps.setDate(3, Date.valueOf(booking.getBookingDate()));

                    boolean inserted = ps.executeUpdate() == 1;
                    con.commit();
                    return inserted;
                }

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    // VIEW BOOKINGS MADE BY A USER
    public List<Booking> findByUser(int userId) throws SQLException {

        String sql = """
                SELECT b.*, h.name AS house_name
                FROM bookings b
                JOIN houses h ON b.house_id = h.id
                WHERE b.user_id = ?
                ORDER BY b.id DESC
                """;

        List<Booking> bookings = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking booking = mapBooking(rs);
                    booking.setHouseName(rs.getString("house_name"));
                    bookings.add(booking);
                }
            }
        }

        return bookings;
    }

    // OWNER VIEWS PENDING BOOKINGS FOR THEIR PROPERTIES
    public List<Booking> findPendingByOwner(int ownerId)
            throws SQLException {

        String sql = """
                SELECT b.*, h.name AS house_name,
                       u.full_name AS user_name
                FROM bookings b
                JOIN houses h ON b.house_id = h.id
                JOIN app_users u ON b.user_id = u.id
                WHERE h.owner_id = ? AND b.status = 'PENDING'
                ORDER BY b.id
                """;

        List<Booking> bookings = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ownerId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Booking booking = mapBooking(rs);
                    booking.setHouseName(rs.getString("house_name"));
                    booking.setUserName(rs.getString("user_name"));
                    bookings.add(booking);
                }
            }
        }

        return bookings;
    }

    // OWNER APPROVES OR REJECTS A BOOKING
    public boolean updateBookingStatus(
            int bookingId, int ownerId, String newStatus)
            throws SQLException {

        try (Connection con = DBConnection.getConnection()) {

            con.setAutoCommit(false);

            try {
                String selectSql = """
                        SELECT b.house_id, b.status, h.available
                        FROM bookings b
                        JOIN houses h ON b.house_id = h.id
                        WHERE b.id = ? AND h.owner_id = ?
                        FOR UPDATE
                        """;

                int houseId;
                String currentStatus;
                boolean available;

                try (PreparedStatement ps =
                        con.prepareStatement(selectSql)) {

                    ps.setInt(1, bookingId);
                    ps.setInt(2, ownerId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "Booking not found for this owner.");
                        }

                        houseId = rs.getInt("house_id");
                        currentStatus = rs.getString("status");
                        available = rs.getBoolean("available");
                    }
                }

                if (!"PENDING".equals(currentStatus)) {
                    throw new SQLException(
                            "This booking has already been processed.");
                }

                if ("APPROVED".equals(newStatus) && !available) {
                    throw new SQLException(
                            "This property is no longer available.");
                }

                String updateSql =
                        "UPDATE bookings SET status = ? WHERE id = ?";

                try (PreparedStatement ps =
                        con.prepareStatement(updateSql)) {

                    ps.setString(1, newStatus);
                    ps.setInt(2, bookingId);
                    ps.executeUpdate();
                }

                if ("APPROVED".equals(newStatus)) {
                    String houseSql = """
                            UPDATE houses SET available = FALSE
                            WHERE id = ? AND available = TRUE
                            """;

                    try (PreparedStatement ps =
                            con.prepareStatement(houseSql)) {

                        ps.setInt(1, houseId);

                        if (ps.executeUpdate() != 1) {
                            throw new SQLException(
                                    "Could not reserve this property.");
                        }
                    }
                }

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    // USER CANCELS THEIR OWN PENDING OR APPROVED BOOKING
    public boolean cancelBooking(int bookingId, int userId)
            throws SQLException {

        try (Connection con = DBConnection.getConnection()) {

            con.setAutoCommit(false);

            try {
                String selectSql = """
                        SELECT house_id, status
                        FROM bookings
                        WHERE id = ? AND user_id = ?
                        FOR UPDATE
                        """;

                int houseId;
                String status;

                try (PreparedStatement ps =
                        con.prepareStatement(selectSql)) {

                    ps.setInt(1, bookingId);
                    ps.setInt(2, userId);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "Booking not found for this user.");
                        }

                        houseId = rs.getInt("house_id");
                        status = rs.getString("status");
                    }
                }

                if (!"PENDING".equals(status)
                        && !"APPROVED".equals(status)) {
                    throw new SQLException(
                            "This booking cannot be cancelled.");
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE bookings SET status = 'CANCELLED' WHERE id = ?")) {
                    ps.setInt(1, bookingId);
                    ps.executeUpdate();
                }

                if ("APPROVED".equals(status)) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE houses SET available = TRUE WHERE id = ?")) {
                        ps.setInt(1, houseId);
                        ps.executeUpdate();
                    }
                }

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    private Booking mapBooking(ResultSet rs) throws SQLException {

        return new Booking(
                rs.getInt("id"),
                rs.getInt("user_id"),
                rs.getInt("house_id"),
                rs.getDate("booking_date").toLocalDate(),
                rs.getString("status")
        );
    }
}
